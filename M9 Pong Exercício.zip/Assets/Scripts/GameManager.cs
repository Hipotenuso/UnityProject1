using TMPro;
using Unity.Burst.Intrinsics;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Transform playerPaddle;
    public Transform enemyPaddle;

    public BallController ballController;

    public int jogadorScore = 0;
    public int enemyScore = 0;
    public TextMeshProUGUI textJogadorPoints;
    public TextMeshProUGUI textEnemyPoints;

    public int winPoints = 5;

    void Start()
    {
        ResetGame();
    }

    public void ResetGame()
    {
        playerPaddle.position = new Vector3(-7f, 0f, 0f);
        enemyPaddle.position = new Vector3(7f, 0f, 0f);
        ballController.ResetBall();
        jogadorScore = 0;
        enemyScore = 0;

        textEnemyPoints.text = enemyScore.ToString();
        textJogadorPoints.text = jogadorScore.ToString();
    }

    public void ScoreJogador()
    {
        jogadorScore++;
        textJogadorPoints.text = jogadorScore.ToString();
        CheckWin();
    }
    
    public void ScoreEnemy()
    {
        enemyScore++;
        textEnemyPoints.text = enemyScore.ToString();
        CheckWin();
    }

    public void CheckWin()
    {
        if (enemyScore >= winPoints)
        {
            ResetGame();
        }
        if (jogadorScore >= winPoints)
        {
            ResetGame();
        }
    }
}
